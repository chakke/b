export const BACKGROUND = [
    {
        bg:  "./assets/departure/background/bg_1.png",
        fg: "#3aa8ff",
    },
    {
        bg:  "./assets/departure/background/bg_2.png",
        fg: "#ffa64d",
    }  
    ,{
        bg:  "./assets/departure/background/bg_3.png",
        fg: "#519b50",
    }
    ,{ 
        bg:  "./assets/departure/background/bg_4.png",
        fg: "#ed827f",
    }
    ,{
        bg:  "./assets/departure/background/bg_5.png",
        fg: "#353188",
    }
    ,{
        bg:  "./assets/departure/background/bg_6.png",
        fg: "#7453f",
    }
    ,{ 
        bg:  "./assets/departure/background/bg_7.png",
        fg: "#109ac1",
    }
    ,{
        bg:  "./assets/departure/background/bg_8.png",
        fg: "#a42b4b",
    }
    ,{
        bg:  "./assets/departure/background/bg_9.png",
        fg: "#1a6745",
    }
    ,{
        bg:  "./assets/departure/background/bg_10.png",
        fg: "#033965",
    }
    
    
    // "./assets/departure/background/bg_1.png",
    // "./assets/departure/background/bg_2.png",
    // "./assets/departure/background/bg_3.png",
    // "./assets/departure/background/bg_5.png",
    // "./assets/departure/background/bg_6.png",
    // "./assets/departure/background/bg_7.png",
    // "./assets/departure/background/bg_8.png",
    // "./assets/departure/background/bg_9.png",
    // "./assets/departure/background/bg_10.png",
]

