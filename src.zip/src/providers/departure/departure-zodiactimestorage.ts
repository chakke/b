export const ZODIACTIME: any[] = [
    {
        can: ["Giáp", "Kỷ"], ti: "Giáp Tý", suu: "Ất Sửu", dan: "Bính Dần", mao: "Đinh Mão", thin: "Mậu Thìn ", ty: "Kỷ Tỵ", ngo: "Canh Ngọ", mui: "Tân Mùi", than: "Nhâm Thân", dau: "Quý Dậu", tuat: "Giáp Tuất", hoi: "Ất Hợi"
    },
    {
        can: ["Ất", "Canh"], ti: "Bính Tý", suu: "Đinh Sửu", dan: "Mậu Dần", mao: "Kỷ Mão", thin: "Canh Thìn ", ty: "Tân Tỵ", ngo: "Nhâm Ngọ", mui: "Quý Mùi", than: "Giáp Thân", dau: "Ất Dậu", tuat: "Bính Tuất", hoi: "Đinh Hợi"
    },
    {
        can: ["Bính", "Tân"], ti: "Mậu Tý", suu: "Kỷ Sửu", dan: "Canh Dần", mao: "Tân Mão", thin: "Nhâm Thìn ", ty: "Quý Tỵ", ngo: "Giáp Ngọ", mui: "Ất Mùi", than: "Bính Thân", dau: "Đinh Dậu", tuat: "Mậu Tuất", hoi: "Kỷ Hợi"
    },
    {
        can: ["Đinh", "Nhâm"], ti: "Canh Tý", suu: "Tân Sửu", dan: "Nhâm Dần", mao: "Quý Mão", thin: "Giáp Thìn ", ty: "Ất Tỵ", ngo: "Bính Ngọ", mui: "Đinh Mùi", than: "Mậu Thân", dau: "Kỷ Dậu", tuat: "Canh Tuất", hoi: "Tân Hợi"
    },
    {
        can: ["Mậu", "Quý"], ti: "Nhâm Tý", suu: "Quý Sửu", dan: "Giáp Dần", mao: "Ất Mão", thin: "Bính Thìn ", ty: "Đinh Tỵ", ngo: "Mậu Ngọ", mui: "Kỷ Mùi", than: "Canh Thân", dau: "Tân Dậu", tuat: "Nhâm Tuất", hoi: "Quý Hợi"
    }
]