export class DepartureCmd{

}