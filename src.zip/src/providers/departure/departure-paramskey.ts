export class DepartureParamsKey{
 
}